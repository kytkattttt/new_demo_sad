import os
from datetime import datetime
import firebase_admin
from firebase_admin import credentials, db, storage
from openpyxl import Workbook

def save_firebase_data_to_excel():
    """
    Saves Firebase data to a new Excel file named 'student_data_{current_date}.xlsx' in the 'output_data' folder.
    """
    # Define the folder to save the Excel file
    output_folder = "output_data"
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Initialize a new Excel workbook
    wb = Workbook()
    ws = wb.active

    # Add headers to the Excel sheet
    ws.append(["ID", "FirstName", "LastName", "MiddleInitial", "Program", "Block", "Course_Code", "Recent_Attendance",
               "Total_Attendance", "Attendance_Status"])

    # Retrieve all students from Firebase
    students_ref = db.reference('Students')
    students = students_ref.get()

    # Populate Excel with Firebase data
    for student_id, student_info in students.items():
        ws.append([
            student_id,
            student_info.get('FirstName', ''),
            student_info.get('lastName', ''),  # Corrected to 'lastName' from 'lastName'
            student_info.get('MiddleInitial', ''),
            student_info.get('Program', ''),
            student_info.get('block', ''),  # Corrected to 'block' from 'Block'
            student_info.get('Course_Code', ''),
            student_info.get('recent_attendance', ''),  # Corrected to 'recent_attendance' from 'Recent_Attendance'
            student_info.get('total_attendance', ''),  # Corrected to 'total_attendance' from 'Total_Attendance'
            student_info.get('attendance_status', '')  # Corrected to 'attendance_status' from 'Attendance_Status'
        ])

    # Save the workbook with a filename based on the current date
    current_date = datetime.now().strftime("%Y-%m-%d")
    excel_filename = os.path.join(output_folder, f"student_data_{current_date}.xlsx")
    wb.save(excel_filename)
    print(f"Firebase data saved to {excel_filename}.")

    # Return the local file path to upload to storage
    return excel_filename


def upload_to_storage(local_file_path, destination_file_name):
    """
    Uploads a local file to Firebase Storage in a specific folder.
    """
    # Define the folder path in Firebase Storage
    storage_folder = "student_data_files"

    # Initialize Firebase Storage client
    bucket = storage.bucket()

    # Create blob object with destination path
    blob = bucket.blob(f"{storage_folder}/{destination_file_name}")

    # Upload the file
    blob.upload_from_filename(local_file_path)

    print(f"File {destination_file_name} uploaded to Firebase Storage in folder {storage_folder}.")


# Call the function to save Firebase data to Excel and get the file path
if __name__ == "__main__":
    excel_file_path = save_firebase_data_to_excel()
    excel_file_name = os.path.basename(excel_file_path)

    # Upload the Excel file to Firebase Storage
    upload_to_storage(excel_file_path, excel_file_name)
