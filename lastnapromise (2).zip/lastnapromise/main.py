from cvzone.FaceDetectionModule import FaceDetector
import os
import pickle
import bbox
import numpy as np
import cvzone
import cv2
import face_recognition
import datetime
from datetime import datetime
from datetime import datetime, timedelta
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from firebase_admin import storage
import xlsxwriter
from xlrd import open_workbook
import csv
import pandas as pd
import openpyxl
from openpyxl import Workbook
from datetime import datetime
import schedule
import time
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import pandas as pd

# Firebase initialization
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://studentattd-db-default-rtdb.asia-southeast1.firebasedatabase.app/',
    'storageBucket': 'studentattd-db.appspot.com'
})

bucket = storage.bucket()
cap = cv2.VideoCapture(1)


# Function to calculate attendance status based on the provided criteria
def calculate_attendance_status(class_start_time, student_recognition_time):
    class_start_time = datetime.strptime(class_start_time, "%H:%M")
    student_recognition_time = datetime.strptime(student_recognition_time, "%H:%M")

    late_threshold = timedelta(minutes=16)
    absent_threshold = timedelta(minutes=90)

    time_difference = student_recognition_time - class_start_time

    if time_difference <= timedelta(minutes=0):
        return "PRESENT"
    elif time_difference <= late_threshold:
        return "LATE"
    elif time_difference > absent_threshold:
        return "ABSENT"
    else:
        return "PRESENT"


cap.set(3, 640)
cap.set(4, 480)

# Load UI images and setup
camUI = cv2.imread('resources/background.png')

folderFilesPath = 'resources/FILES'
filesPathList = os.listdir(folderFilesPath)
imgFilesList = []
for path in filesPathList:
    imgFilesList.append(cv2.imread(os.path.join(folderFilesPath, path)))

file = open('DneEncodeFile.pickle', 'rb')
encodeListSearchedWithIds = pickle.load(file)
file.close()
encodeListSearched, studentsId = encodeListSearchedWithIds

imgFileType = 0
counter = 0
id = -1
imageStudents = []

wb = Workbook()
ws = wb.active
ws.append(["ID", "Name", "Total Attendance", "Last Attendance Time"])

last_attendance_time_dict = {}

while True:
    success, img = cap.read()
    imgSize = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgSize = cv2.cvtColor(imgSize, cv2.COLOR_BGR2RGB)
    facesFrame = face_recognition.face_locations(imgSize)
    eFrame = face_recognition.face_encodings(imgSize, facesFrame)
    camUI[162:162 + 480, 55:55 + 640] = img
    camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

    if facesFrame:
        for encodeFace, faceLocation in zip(eFrame, facesFrame):
            matches = face_recognition.compare_faces(encodeListSearched, encodeFace)
            distance = face_recognition.face_distance(encodeListSearched, encodeFace)
            matchIndx = np.argmin(distance)

            if matches[matchIndx]:
                y1, x2, y2, x1 = faceLocation
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                bbox = 55 + x1, 162 + y1, x2 - x1, y2 - y1
                camUI = cvzone.cornerRect(camUI, bbox, rt=0, t=1)

                id = studentsId[matchIndx]
                attendance_folder = 'attendance_records'

                if not os.path.exists(attendance_folder):
                    os.makedirs(attendance_folder)

                student_info = db.reference(f'Students/{id}').get()
                datetime_now = datetime.now()
                current_date = datetime_now.strftime("%Y-%m-%d")
                attendance_file_name = f"attendance_record_{current_date}.xlsx"
                attendance_file_path = os.path.join(attendance_folder, attendance_file_name)

                if not os.path.exists(attendance_file_path):
                    attendance_workbook = Workbook()
                    attendance_sheet = attendance_workbook.active
                    attendance_sheet.append(
                        ["ID", "Name", "Program", "Block&Year", "Total Attendance", "Date/Time", "Attendance Status"])
                else:
                    attendance_workbook = openpyxl.load_workbook(attendance_file_path)
                    attendance_sheet = attendance_workbook.active

                    existing_attendance_records = attendance_sheet.values
                    existing_attendance_records = [record for record in existing_attendance_records if record[0] == id]

                    if existing_attendance_records:
                        print("Student has already attended today.")
                        attendance_workbook.close()

                # Record student attendance and determine attendance status
                attendance_status = calculate_attendance_status("12:00", datetime_now.strftime("%H:%M"))
                attendance_sheet.append([id, student_info['name'], student_info['Program'], student_info['block&year'],
                                         student_info['total_attendance'], datetime_now.strftime("%Y-%m-%d %H:%M:%S"),
                                         attendance_status])
                attendance_workbook.save(attendance_file_path)

                # Update Firebase Realtime Database with attendance status
                ref = db.reference(f'Students/{id}')
                ref.update({
                    'attendance_status': attendance_status
                })

                last_attendance_time_dict[id] = datetime_now

                # imgfiletype start for ui
                if counter == 0:
                    font_face = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = 2.5
                    cv2.putText(camUI, "", (100, 400), font_face, font_scale, (255, 0, 0), 2)
                    cv2.waitKey(1)
                    counter = 1
                    imgFileType = 1

            if counter != 0:

                if counter == 1:
                    # data
                    studentsIdInfo = db.reference(f'Students/{id}').get()
                    print(studentsIdInfo)

                    # get image
                    blob = bucket.blob(f'Images/{id}.png')
                    array = np.frombuffer(blob.download_as_string(), np.uint8)
                    imageStudents = cv2.imdecode(array, cv2.COLOR_BGR2RGB)

                    # data of attendance

                    datetimeObject = datetime.strptime(studentsIdInfo['recent_attendance'],
                                                       "%Y-%m-%d %H:%M:%S")
                    secondsElapsed = (datetime.now() - datetimeObject).total_seconds()
                    print(secondsElapsed)
                    if secondsElapsed > 36000:
                        ref = db.reference(f'Students/{id}')
                        studentsIdInfo['total_attendance'] = int(studentsIdInfo.get('total_attendance', 0)) + 1

                        ref.child('total_attendance').set(studentsIdInfo['total_attendance'])
                        ref.child('recent_attendance').set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    else:
                        imgFileType = 3
                        counter = 0
                        camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

            if imgFileType != 3:

                if 10 < counter < 20:
                    imgFileType = 2

                camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

                if counter <= 10:
                    cv2.putText(camUI, str(studentsIdInfo['Program']), (1006, 550),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)
                    cv2.putText(camUI, str(studentsIdInfo['block&year']), (1006, 610),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)
                    cv2.putText(camUI, str(id), (1006, 493),
                                cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)

                    (w, h), _ = cv2.getTextSize(studentsIdInfo['name'], cv2.FONT_HERSHEY_COMPLEX, 1, 1)
                    offset = (440 - w) // 2
                    cv2.putText(camUI, str(studentsIdInfo['name']), (810 + offset, 445),
                                cv2.FONT_HERSHEY_COMPLEX, 0.8, (100, 100, 100), 1)

                    camUI[175:175 + 216, 909:909 + 216] = imageStudents

                counter += 1

                if counter >= 20:
                    counter = 0
                    imgFileType = 0
                    studentsIdInfo = []
                    imageStudents = []
                    camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]
    else:
        imgFileType = 0
        counter = 0

    #cv2.imshow("attendance", img)
    cv2.imshow("IDENTIFACE", camUI)
    cv2.waitKey(1)
