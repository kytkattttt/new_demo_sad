import os
from pathlib import Path
from tkinter import Tk, Canvas, Button, PhotoImage, messagebox

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"C:\Users\PC\Documents\Downloads\lastnapromise\assets\frame2")

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

window = Tk()
window.title('Selection')
width_of_window = 780
height_of_window = 480
window.configure(bg="#FFFFFF")
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_coordinate = (screen_width / 2) - (width_of_window / 2)
y_coordinate = (screen_height / 2) - (height_of_window / 2)
window.geometry("%dx%d+%d+%d" % (width_of_window, height_of_window, x_coordinate, y_coordinate))
window.overrideredirect(1)

canvas = Canvas(
    window,
    bg="#FFFFFF",
    height=488,
    width=780,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas.place(x=0, y=0)

block_chosen = False
course_chosen = False

def run_attendance_script():
    global block_chosen, course_chosen
    if not block_chosen or not course_chosen:
        messagebox.showwarning("Warning", "Choose block and course first!")
    else:
        print("take attendance")
        os.system("python demo.py")

def button2_clicked():
    global block_chosen
    block_chosen = True
    print("Block chosen")
    os.system("python database.py")


def button3_clicked():
    global course_chosen
    if not block_chosen:
        messagebox.showwarning("Warning", "Choose block first!")
    else:
        course_chosen = True
        print("Course chosen")
        os.system("python student-info-encode.py")


def button1_clicked():
    global block_chosen, course_chosen
    if not block_chosen or not course_chosen:
        messagebox.showwarning("Warning", "Choose block and course first!")
    else:
        os.system("python attendance-taking.py")
        print("Attendance taking")

def on_escape(event):
    window.destroy()

window.bind('<Escape>', on_escape)

# Load images
image_image_1 = PhotoImage(file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(390.8946349970229, 246.432373046875, image=image_image_1)

image_image_2 = PhotoImage(file=relative_to_assets("image_2.png"))
image_2 = canvas.create_image(389.8754699608312, 293.44482421875, image=image_image_2)

button_image_1 = PhotoImage(file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=run_attendance_script,
    relief="flat"
)
button_1.place(x=278.0, y=332.0, width=224.0, height=25.20311737060547)

button_image_2 = PhotoImage(file=relative_to_assets("button_2.png"))
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=button2_clicked,
    relief="flat"
)
button_2.place(x=278.0, y=250.0, width=227.38267517089844, height=28.67021369934082)

button_image_3 = PhotoImage(file=relative_to_assets("button_3.png"))
button_3 = Button(
    image=button_image_3,
    borderwidth=0,
    highlightthickness=0,
    command=button3_clicked,
    relief="flat"
)
button_3.place(x=276.0, y=294.0, width=227.38267517089844, height=28.67021369934082)

canvas.create_text(308.0, 219.0, anchor="nw", text="Available Block", fill="#3F3D3D", font=("Poppins Regular", 12 * -1))

window.resizable(False, False)
window.mainloop()
