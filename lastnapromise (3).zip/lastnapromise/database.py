import firebase_admin
from firebase_admin import credentials, db
import json
import os

# Firebase initialization
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://studentattd-db-default-rtdb.asia-southeast1.firebasedatabase.app/',

})
print("Firebase initialized successfully.")


students_ref = db.reference('Students')


students_data = students_ref.get()
print("Data read from Firebase:")


print(json.dumps(students_data, indent=4))


output_file_path = "students_data.json"


with open(output_file_path, 'w') as json_file:
    json.dump(students_data, json_file, indent=4)

print(f"Data has been saved locally to {output_file_path}")


with open("students_data.json", 'r') as json_file:
    local_data = json.load(json_file)

print("Data read from local JSON file:")
print(json.dumps(local_data, indent=4))
