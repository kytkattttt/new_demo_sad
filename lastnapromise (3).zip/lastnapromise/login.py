import tkinter as tk
from tkinter import messagebox
import re
import subprocess
import firebase_admin
from firebase_admin import credentials, auth, firestore

# Firebase initialization
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()


def validate_login():
    email = entry_1.get().strip()
    password = entry_2.get().strip()

    try:
        if not email or not password:
            raise ValueError("Email and password cannot be empty")

        # Validate password complexity (optional)
        if not is_valid_password(password):
            raise ValueError("Password must be at least 8 characters long "
                             "and contain uppercase letters, lowercase letters, and numbers")

        # Authenticate user with email and password
        user = auth.get_user_by_email(email)
        auth.verify_password(user.uid, password)

        # If authentication is successful, open blockselection.py
        open_block_selection()

    except ValueError as ve:
        messagebox.showerror("Login Failed", str(ve))  # Show error message
    except auth.UserNotFoundError:
        messagebox.showerror("Login Failed", "User not found")  # User not found error
    except auth.InvalidPasswordError:
        messagebox.showerror("Login Failed", "Incorrect password")  # Incorrect password error
    except firebase_admin.auth.FirebaseAuthError as e:
        messagebox.showerror("Firebase Authentication Error", str(e))  # Firebase authentication error


def is_valid_password(password):
    # Password must be at least 8 characters long and contain uppercase letters, lowercase letters, and numbers
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    return True


def open_block_selection():
    # Open blockselection.py using subprocess
    subprocess.Popen(["python", "blockselection.py"])


def on_key_press(event):
    if event.keysym == 'Escape':
        window.destroy()


# Tkinter window setup
window = tk.Tk()
window.title('Login')
width_of_window = 780
height_of_window = 480
window.configure(bg="#FFFFFF")
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_coordinate = (screen_width / 2) - (width_of_window / 2)
y_coordinate = (screen_height / 2) - (height_of_window / 2)
window.geometry("%dx%d+%d+%d" % (width_of_window, height_of_window, x_coordinate, y_coordinate))
window.overrideredirect(1)

canvas = tk.Canvas(
    window,
    bg="#FFFFFF",
    height=488,
    width=780,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas.place(x=0, y=0)

# Assuming these are PNG files in your 'assets/frame1' directory
image_image_1 = tk.PhotoImage(file="assets/frame1/image_1.png")
entry_image_1 = tk.PhotoImage(file="assets/frame1/entry_1.png")
entry_image_2 = tk.PhotoImage(file="assets/frame1/entry_2.png")
button_image_1 = tk.PhotoImage(file="assets/frame1/button_1.png")

# Create GUI elements
image_1 = canvas.create_image(
    390.0,
    244.0,
    image=image_image_1
)

canvas.create_text(
    235.0,
    140.0,
    anchor="nw",
    text="E-Mail / Username",
    fill="#554E80",
    font=("Poppins Regular", 20)
)

canvas.create_text(
    235.0,
    262.0,
    anchor="nw",
    text="Password",
    fill="#554E80",
    font=("Poppins Regular", 20)
)

entry_bg_1 = canvas.create_image(
    389.5,
    202.0,
    image=entry_image_1
)
entry_1 = tk.Entry(
    bd=0,
    bg="#F2F2F2",
    fg="#000716",
    highlightthickness=0
)
entry_1.place(
    x=243.0,
    y=177.0,
    width=293.0,
    height=48.0
)

entry_bg_2 = canvas.create_image(
    389.5,
    321.0,
    image=entry_image_2
)
entry_2 = tk.Entry(
    bd=0,
    bg="#F2F2F2",
    fg="#000716",
    highlightthickness=0,
    show="*"  # Mask the password entry
)
entry_2.place(
    x=243.0,
    y=296.0,
    width=293.0,
    height=48.0
)

button_1 = tk.Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=validate_login,
    relief="flat"
)
button_1.place(
    x=321.0,
    y=389.0,
    width=137.0,
    height=39.0
)

window.bind('<Escape>', on_key_press)

window.resizable(False, False)
window.mainloop()
