import subprocess
from pathlib import Path
import threading
from tkinter import Tk, Canvas, Button, PhotoImage, StringVar, messagebox

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(
    r"C:\Users\LENOVO LEGION\Downloads\final-facerecogbased-attendance (3)\final-facerecogbased-attendance\assets\frame0")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


def enable_attendance_button():
    selected_class.set("Class Selected")
    button_1.config(state="normal")


def run_main():
    try:
        subprocess.run(["python", "demo.py"], check=True)
        window.destroy()  # Close tkinter window after running main.py
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Failed to open main.py: {e}")


def handle_attendance_click():
    if selected_class.get() == "No Class Selected":
        messagebox.showwarning("Warning", "Please select a class first!")
    else:
        print("Attendance button clicked")
        # Run main.py in a separate thread
        thread = threading.Thread(target=run_main)
        thread.start()


def quit_on_key(event):
    if event.char == 'q':
        window.destroy()


window = Tk()
window.title('selection')
window.configure(bg="#FFFFFF")
width_of_window = 780
height_of_window = 480
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_coordinate = (screen_width / 2) - (width_of_window / 2)
y_coordinate = (screen_height / 2) - (height_of_window / 2)
window.geometry("%dx%d+%d+%d" % (width_of_window, height_of_window, x_coordinate, y_coordinate))
window.overrideredirect(1)

canvas = Canvas(
    window,
    bg="#FFFFFF",
    height=488,
    width=780,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)
canvas.place(x=0, y=0)

image_image_1 = PhotoImage(file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(
    390.8946349970229,
    246.432373046875,
    image=image_image_1
)

selected_class = StringVar(value="No Class Selected")

button_image_1 = PhotoImage(file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=handle_attendance_click,
    relief="flat"
)
button_1.place(
    x=278.0,
    y=285.0,
    width=224.0,
    height=27.423583984375
)

image_image_2 = PhotoImage(file=relative_to_assets("image_2.png"))
image_2 = canvas.create_image(
    390.10563270347257,
    262.44482421875,
    image=image_image_2
)

button_image_2 = PhotoImage(file=relative_to_assets("button_2.png"))
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=enable_attendance_button,
    relief="flat"
)
button_2.place(
    x=277.0,
    y=244.0,
    width=227.38267517089844,
    height=28.67021369934082
)

canvas.create_text(
    350.0,
    216.0,
    anchor="nw",
    text="Available Block",
    fill="#3F3D3D",
    font=("Poppins Regular", 12 * -1)
)

canvas.create_rectangle(
    304.0,
    307.976203976325,
    473.0005645751953,
    309.0,
    fill="#DADADA",
    outline=""
)

window.bind('<Key>', quit_on_key)

window.resizable(False, False)
window.mainloop()
