from datetime import datetime, timedelta
import os
import pickle
import numpy as np
import cv2
import face_recognition
import firebase_admin
from firebase_admin import credentials, db, storage
from openpyxl import Workbook, load_workbook

# Firebase initialization
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://studentattd-db-default-rtdb.asia-southeast1.firebasedatabase.app/',
    'storageBucket': 'studentattd-db.appspot.com'
})
bucket = storage.bucket()

# OpenCV video capture setup
cap = cv2.VideoCapture(1)
cap.set(3, 640)
cap.set(4, 480)

# Load UI images
camUI = cv2.imread('resources/background.png')
folderFilesPath = 'resources/FILES'
imgFilesList = [cv2.imread(os.path.join(folderFilesPath, path)) for path in os.listdir(folderFilesPath)]

# Load face encodings from pickle file
with open('DneEncodeFile.pickle', 'rb') as file:
    encodeListSearchedWithIds = pickle.load(file)
encodeListSearched, studentsId = encodeListSearchedWithIds

imgFileType = 0
counter = 0
id = -1
imageStudents = []

# Initialize workbook for attendance records
wb = Workbook()
ws = wb.active
ws.append(["ID", "Name", "Total Attendance", "Last Attendance Time"])

last_attendance_time_dict = {}

# Function to capture and save student image
# Dictionary to store last captured time for each student
last_capture_time = {}


# Function to capture and save student image
def capture_and_save_image(student_id, img):
    global last_capture_time
    student_image_folder = f'Captured_Images/{student_id}'
    if not os.path.exists(student_image_folder):
        os.makedirs(student_image_folder)

    # Check last captured time for the student
    if student_id in last_capture_time:
        last_time = last_capture_time[student_id]
        time_elapsed = datetime.now() - last_time
        if time_elapsed < timedelta(hours=10):
            print(f"Skipping capture for {student_id} as last capture was {time_elapsed.total_seconds()} seconds ago.")
            return

    # Capture and save image
    img_filename = datetime.now().strftime("%Y%m%d_%H%M%S") + '.png'
    img_path = os.path.join(student_image_folder, img_filename)

    cv2.imwrite(img_path, img)
    print(f"Saved image for student {student_id} at {img_path}")

    # Update last capture time
    last_capture_time[student_id] = datetime.now()


# Function to calculate attendance status
def calculate_attendance_status(class_start_time, student_recognition_time):
    class_start_time = datetime.strptime(class_start_time, "%H:%M")
    student_recognition_time = datetime.strptime(student_recognition_time, "%H:%M")

    late_threshold = timedelta(minutes=16)
    absent_threshold = timedelta(minutes=90)

    time_difference = student_recognition_time - class_start_time

    if time_difference <= timedelta(minutes=15):
        return "PRESENT"
    elif time_difference <= late_threshold:
        return "LATE"
    elif time_difference > absent_threshold:
        return "ABSENT"
    else:
        return "PRESENT"


# Main loop for video capture and processing
while True:
    success, img = cap.read()
    imgSize = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgSize = cv2.cvtColor(imgSize, cv2.COLOR_BGR2RGB)
    facesFrame = face_recognition.face_locations(imgSize)
    eFrame = face_recognition.face_encodings(imgSize, facesFrame)
    camUI[162:162 + 480, 55:55 + 640] = img
    camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

    if facesFrame:
        for encodeFace, faceLocation in zip(eFrame, facesFrame):
            matches = face_recognition.compare_faces(encodeListSearched, encodeFace)
            distance = face_recognition.face_distance(encodeListSearched, encodeFace)
            matchIndx = np.argmin(distance)

            if matches[matchIndx]:
                y1, x2, y2, x1 = faceLocation
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                bbox = 55 + x1, 162 + y1, x2 - x1, y2 - y1
                camUI = cv2.rectangle(camUI, (bbox[0], bbox[1]), (bbox[0] + bbox[2], bbox[1] + bbox[3]), (255, 0, 0), 2)

                id = studentsId[matchIndx]
                capture_and_save_image(id, img)
                attendance_folder = 'attendance_records'

                if not os.path.exists(attendance_folder):
                    os.makedirs(attendance_folder)

                student_info = db.reference(f'Students/{id}').get()
                datetime_now = datetime.now()
                current_date = datetime_now.strftime("%Y-%m-%d")
                attendance_file_name = f"attendance_record_{current_date}.xlsx"
                attendance_file_path = os.path.join(attendance_folder, attendance_file_name)

                if not os.path.exists(attendance_file_path):
                    attendance_workbook = Workbook()
                    attendance_sheet = attendance_workbook.active
                    attendance_sheet.append(
                        ["ID", "Name", "Program", "Block", "Total Attendance", "Date/Time", "Attendance Status"])
                else:
                    attendance_workbook = load_workbook(attendance_file_path)
                    attendance_sheet = attendance_workbook.active

                    existing_attendance_records = attendance_sheet.values
                    existing_attendance_records = [record for record in existing_attendance_records if record[0] == id]

                    if existing_attendance_records:
                        print("Student has already attended today.")
                        attendance_workbook.close()
                try:
                    attendance_status: str = calculate_attendance_status("07:00", datetime_now.strftime("%H:%M"))
                    attendance_sheet.append([
                        id,
                        student_info.get('FirstName', ''),
                        student_info.get('lastName', ''),
                        student_info.get('MiddleInitial', ''),
                        student_info.get('Program', ''),
                        student_info.get('block', ''),
                        student_info.get('total_attendance', ''),
                        datetime_now.strftime("%Y-%m-%d %H:%M:%S"),
                        attendance_status
                    ])
                    attendance_workbook.save(attendance_file_path)

                    ref = db.reference(f'Students/{id}')
                    ref.update({
                        'attendance_status': attendance_status
                    })

                    last_attendance_time_dict[id] = datetime_now

                    if counter == 0:
                        font_face = cv2.FONT_HERSHEY_SIMPLEX
                        font_scale = 2.5
                        cv2.putText(camUI, "", (100, 400), font_face, font_scale, (255, 0, 0), 2)
                        cv2.waitKey(1)
                        counter = 1
                        imgFileType = 1

                    if counter != 0:
                        if counter == 1:
                            studentsIdInfo = db.reference(f'Students/{id}').get()
                            print(studentsIdInfo)

                            blob = bucket.blob(f'Images/{id}.png')
                            array = np.frombuffer(blob.download_as_string(), np.uint8)
                            imageStudents = cv2.imdecode(array, cv2.COLOR_BGR2RGB)

                            datetimeObject = datetime.strptime(studentsIdInfo['recent_attendance'], "%Y-%m-%d %H:%M:%S")
                            secondsElapsed = (datetime.now() - datetimeObject).total_seconds()
                            print(secondsElapsed)
                            if secondsElapsed > 36000:
                                ref = db.reference(f'Students/{id}')
                                studentsIdInfo['total_attendance'] = int(studentsIdInfo.get('total_attendance', 0)) + 1

                                ref.child('total_attendance').set(studentsIdInfo['total_attendance'])
                                ref.child('recent_attendance').set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                            else:
                                imgFileType = 3
                                counter = 0
                                camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

                    if imgFileType != 3:
                        if 10 < counter < 20:
                            imgFileType = 2

                        camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

                        if counter <= 10:
                            cv2.putText(camUI, str(studentsIdInfo.get('Program', '')), (1006, 550),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)
                            cv2.putText(camUI, str(studentsIdInfo.get('block', '')), (1006, 610),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)
                            cv2.putText(camUI, str(id), (1006, 493),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (50, 50, 50), 1)

                            full_name = f"{studentsIdInfo.get('FirstName', '')} {studentsIdInfo.get('MiddleInitial', '')} {studentsIdInfo.get('lastName', '')}".strip()
                            (w, h), _ = cv2.getTextSize(full_name, cv2.FONT_HERSHEY_COMPLEX, 1, 1)
                            offset = (440 - w) // 2
                            cv2.putText(camUI, full_name, (810 + offset, 445),
                                        cv2.FONT_HERSHEY_COMPLEX, 0.8, (100, 100, 100), 1)

                            camUI[175:175 + 216, 909:909 + 216] = imageStudents

                except KeyError as e:
                    print(f"KeyError: {e}")
                except Exception as e:
                    print(f"An unexpected error occurred: {e}")

                counter += 1

                if counter >= 20:
                    counter = 0
                    imgFileType = 0
                    studentsIdInfo = []
                    imageStudents = []
                    camUI[44:44 + 633, 808:808 + 414] = imgFilesList[imgFileType]

    else:
        imgFileType = 0
        counter = 0

    cv2.imshow("IDENTIFACE", camUI)
    cv2.waitKey(1)
