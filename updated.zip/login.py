from pathlib import Path
from tkinter import Tk, Canvas, Entry, Button, PhotoImage, messagebox
import subprocess

# from tkinter import *
# Explicit imports to satisfy Flake8
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage


OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"C:\Users\LENOVO LEGION\Downloads\final-facerecogbased-attendance (3)\final-facerecogbased-attendance\assets\frame1")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


window = Tk()
window.title('Login')
window.configure(bg = "#FFFFFF")
width_of_window = 780
height_of_window = 480
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
x_coordinate = (screen_width/2)-(width_of_window/2)
y_coordinate = (screen_height/2)-(height_of_window/2)
window.geometry("%dx%d+%d+%d" %(width_of_window,height_of_window,x_coordinate,y_coordinate))
window.overrideredirect(1)



canvas = Canvas(
    window,
    bg = "#FFFFFF",
    height = 488,
    width = 780,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
image_image_1 = PhotoImage(
    file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(
    390.0,
    244.0,
    image=image_image_1
)

canvas.create_text(
    235.0,
    140.0,
    anchor="nw",
    text="E-Mail / Username",
    fill="#554E80",
    font=("Poppins Regular", 20 * -1)
)

canvas.create_text(
    235.0,
    262.0,
    anchor="nw",
    text="Password",
    fill="#554E80",
    font=("Poppins Regular", 20 * -1)
)

entry_image_1 = PhotoImage(
    file=relative_to_assets("entry_1.png"))
entry_bg_1 = canvas.create_image(
    389.5,
    202.0,
    image=entry_image_1
)
entry_1 = Entry(
    bd=0,
    bg="#F2F2F2",
    fg="#000716",
    highlightthickness=0
)
entry_1.place(
    x=243.0,
    y=177.0,
    width=293.0,
    height=48.0
)

entry_image_2 = PhotoImage(
    file=relative_to_assets("entry_2.png"))
entry_bg_2 = canvas.create_image(
    389.5,
    321.0,
    image=entry_image_2
)
entry_2 = Entry(
    bd=0,
    bg="#F2F2F2",
    fg="#000716",
    highlightthickness=0,
    show = "*"  # Mask the password entry
)
entry_2.place(
    x=243.0,
    y=296.0,
    width=293.0,
    height=48.0
)
def validate_login():
    email = entry_1.get()
    password = entry_2.get()
    if email == "test1234@gmail.com" and password == "12345678":
        open_main_script()  # Open the main.py script
    else:
        messagebox.showerror("Login Failed", "Invalid Email or Password")

# Function to open the main.py script
def open_main_script():
    window.destroy()  # Close the login window
    subprocess.run(["python", "classselection.py"])

button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=validate_login,
    relief="flat"
)
button_1.place(
    x=321.0,
    y=389.0,
    width=137.0,
    height=39.0
)
window.resizable(False, False)
window.mainloop()
