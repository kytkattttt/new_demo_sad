from flask import Flask, request, jsonify, send_from_directory
import cv2
import numpy as np
import face_recognition
import firebase_admin
from firebase_admin import credentials, db, storage
import pickle
import os

# Initialize Firebase
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://studentattd-db-default-rtdb.asia-southeast1.firebasedatabase.app/',
    'storageBucket': 'studentattd-db.appspot.com'
})

local_folder = 'images'
if not os.path.exists(local_folder):
    os.makedirs(local_folder)

bucket = storage.bucket()

blobs = bucket.list_blobs()
image_files = [blob for blob in blobs if blob.name.endswith(('png', 'jpg', 'jpeg'))]

for blob in image_files:
    local_image_path = os.path.join(local_folder, os.path.basename(blob.name))
    blob.download_to_filename(local_image_path)
    print(f"Downloaded {blob.name} to {local_image_path}")

img_list = []
students_id = []

for image_file in image_files:
    image_path = os.path.join(local_folder, os.path.basename(image_file.name))
    img = cv2.imread(image_path)
    if img is not None:
        img_list.append(img)
        students_id.append(os.path.splitext(os.path.basename(image_file.name))[0])
    else:
        print(f"Error reading image {image_path}")

print("Images and IDs read successfully.")


def find_encodings(image_list):
    encode_list = []
    for img in image_list:
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encodings = face_recognition.face_encodings(rgb_img)
        if encodings:
            encode_list.append(encodings[0])
        else:
            print("No face found in image.")
    return encode_list


print("Encoding started...")
encode_list_searched = find_encodings(img_list)
encode_list_searched_with_ids = [encode_list_searched, students_id]
print("Encoding finished")

# Save the encodings to a local pickle file
pickle_file_path = "DneEncodeFile.pickle"
with open(pickle_file_path, 'wb') as file:
    pickle.dump(encode_list_searched_with_ids, file)
print("Encodings saved to DneEncodeFile.pickle.")
